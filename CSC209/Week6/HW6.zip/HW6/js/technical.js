function drawGrid() {
    const canvas = document.getElementById("myCanvas");
    const ctx = canvas.getContext("2d");
    ctx.lineWidth = 2;

    let squares = [];

    this.drawSquare = function() {
        ctx.clearRect(0, 0, 400, 400);
        squares = [];
        var x = 0;

        while (x < canvas.width / 2) {
            var y = 0;
            while ( y < canvas.height) {
                
            }

        }
        
        // spacing is too narrow; need to somehow expand for size of canvas
        for (let i = 2; i < 6; i++) {
            let x = canvas.width / i;
            let y = canvas.height / i;
 
            console.log(x, y); // debugging, checking coords
            
            squares.push({
                x: x,
                y: y,

                draw: function() {
                    ctx.strokeStyle = "#000000";
                    ctx.beginPath();
                    ctx.rect(x,y, canvas.width / 5, canvas.height / 5);
                    ctx.stroke();
                }
            })

            console.log(squares); // debugging, checking array

        } squares.forEach(square => {
            square.draw();
        })


    }
}

let game;

function initGame() {
    game = new drawGrid();
    game.drawSquare();
}