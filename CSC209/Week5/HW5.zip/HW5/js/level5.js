const canvas = document.getElementById("myCanvas");
const ctx = canvas.getContext("2d");
ctx.lineWidth = 2;
var x;
var y;
var velocity;
var id = null;
// make an array of the created circles w/ coordinates + velociites stored
var circles = [{x: null, y: null, vx: null, vy:null}]

// draw circles... do these need to be objects maybe???
// store data for x and y
function drawCircle() {
    ctx.clearRect(0,0,400,400);
    var NRPTS = document.getElementById("NRPTS").value;
    
    for (i=0; i < NRPTS; i++) {
        ctx.strokeStyle = randomColor();
        ctx.beginPath();
        randomLocation();
        ctx.arc(x, y, 25, 0, 2 * Math.PI);
        ctx.stroke();
    
        ctx.beginPath();
        ctx.moveTo(x,y);
        ctx.lineTo(x+Math.random()*50, y+Math.random()*50);
        ctx.stroke(); 

        // somehow add to the array 
        circles.add({x,y,x,y});
    }
}

// Generate random color
function randomColor() {
    var letters = '0123456789ABCDEF';
    var hexColor = '#';
    for (var i = 0; i < 6; i++) {
      hexColor += letters[Math.floor(Math.random() * 16)];
    }
    
    return hexColor;
}

// Generate random location
function randomLocation() {
    randomX();
    randomY();
}
function randomX() {
    x = Math.random() * 400;

    return x;
}
function randomY() {
    y = Math.random() * 400;

    return y;
}

function randomVelocity() {
    num = Math.random() * 4;

    if (num = 1) {
        velocity = 10;
    } else if (num = 2) {
        velocity = 20;
    } else if (num = 3) {
        velocity = 30;
    }

    return velocity;
}

// Animate circles
// Adapt this from object to canvas element 
function moveCircle() {
    // Somehow need to target the shape even tho they don't have any id?
    var elem = document.getElementById();
    // Somehow need to get position even tho its random
    var pos;

    clearInterval(id);

    // somehow need to be able to have the interval be at a specified velocity shown by line
    id = setInterval(frame,10);

    function frame() {
        if (pos = 400) {
            clearInterval(id);
        } else {
            pos++;
            elem.style.top=pos + 'px';
            elem.style.left=pos + 'px';
        }
    }

}